//
//  Note.swift
//  Notes
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//

import Foundation

struct Note: Equatable {
    var text: String
}
